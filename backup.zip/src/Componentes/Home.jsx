import React from 'react';

function Home() {
    return ( 
        <img src="/image.png" alt="Logo" style={{ display: 'block', margin: 'auto', backgroundColor: 'transparent' }} />
     );
}

export default Home;
